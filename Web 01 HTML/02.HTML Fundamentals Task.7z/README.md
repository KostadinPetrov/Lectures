HTML Fundamentals
=================

### Problem 1. Runners Home page
*	Write an HTML page like the following:

_Note: use headings, divs, paragraphs and ul_

![picture1](https://cloud.githubusercontent.com/assets/3619393/7002604/e4dadf2a-dc55-11e4-9743-76f4cf0c3f5b.png)


### Problem 2. Nested Lists
*	Write an HTML page like the following:

![picture2](https://cloud.githubusercontent.com/assets/3619393/7002607/ee1e65c0-dc55-11e4-966e-2eb85ea38c0d.png)

### Problem 3. Social site
*	Create an user profile Web page `profile.html`, friends page named `friends.html` and info page named `home.html`.
*	Link them to one another using `<a>` tag

![picture3](https://cloud.githubusercontent.com/assets/3619393/7002582/b53708fc-dc55-11e4-88f9-831a63a7a6c0.png)

![picture4](https://cloud.githubusercontent.com/assets/3619393/7002592/c14ee27c-dc55-11e4-85c5-42fefe9f9751.png)

![picture5](https://cloud.githubusercontent.com/assets/3619393/7002594/c9f92266-dc55-11e4-8396-f5ac08234561.png)
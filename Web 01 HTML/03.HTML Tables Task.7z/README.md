HTML Tables
===========

### Problem 1. HTML Tables
*	Create Web Pages like the following using tables:

![picture1](https://cloud.githubusercontent.com/assets/3619393/7002979/ae5d2178-dc5b-11e4-8a15-2d8a574ba5b9.png)

![picture2](https://cloud.githubusercontent.com/assets/3619393/7002980/afb04c76-dc5b-11e4-917f-4e8fe696cf57.png)

### Problem 2. HTML Form
*	Create a Web Page like the following using forms:

![picture3](https://cloud.githubusercontent.com/assets/3619393/7002981/b2a274b8-dc5b-11e4-9868-68675b7d328e.png)

### Problem 3. Calculator
*	Create a Calculator-like table. You should use a HTML 5 form for the Calculator.
	*	Buttons for all the numbers and operators (+, -, etc.)
	*	Textbox for the result
	
![picture4](https://cloud.githubusercontent.com/assets/3619393/7002982/b3d1f3c2-dc5b-11e4-89ed-a3b2e52f32b9.png)

_Note: Do not make the same styles as the example_

_Note: Do not implement functionalities_
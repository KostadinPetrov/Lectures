HTML Forms and Frames
=====================

### Problem 1. Registration form
*	Create a Web form that looks like this sample:

![picture1](https://cloud.githubusercontent.com/assets/3619393/7003233/b2d1d68c-dc5f-11e4-8758-72d6af6d5cc0.png)

### Problem 2. University grid
*	Create the following using tables and forms:

![picture2](https://cloud.githubusercontent.com/assets/3619393/7003232/b2d14942-dc5f-11e4-9cff-abf76d3f3e14.png)

### Problem 3. Notebook store
*	Create the following HTML Page:

_Hint: Use Fieldsets and Nested tables_
	
![picture3](https://cloud.githubusercontent.com/assets/3619393/7003235/b2d26052-dc5f-11e4-88c4-de356e7fcc2f.png)
		
### Problem 4.* Grid component
*	Construct the following Grid component:
	*	Try to make a HTML page, that looks just like the example
	*	CSS is required

![picture4](https://cloud.githubusercontent.com/assets/3619393/7003234/b2d1eb4a-dc5f-11e4-8844-f1462f705ddf.png)

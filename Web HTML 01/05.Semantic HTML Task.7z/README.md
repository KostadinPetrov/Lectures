Semantic HTML
=============

### Problem 1. Refactoring
*	Refactor (edit) the [homework-refactoring.html](https://github.com/TelerikAcademy/HTML/blob/master/Topics/05.%20Semantic-HTML/homework/homework-refactoring.html) web page and make it HTML semantic.

### Problem 2. Student System
*	Create a web page using semantic HTML by the design.
*	Use some kind of approach to support old (non-HTML5-compatible) Web browsers like IE8.

![picture1](https://cloud.githubusercontent.com/assets/3619393/7179645/ba6f880e-e442-11e4-9f54-235e88cb686a.png)

_Note: Do not try to make the same styles. Implement just the content with its semantics._

### Problem 3. LinkedIn
*	Create a web page using semantic HTML by the design.

![picture2](https://cloud.githubusercontent.com/assets/3619393/7179271/ac996bf4-e43e-11e4-981f-d0914a8ca92d.png)

_Note: Do not try to make the same styles. Implement just the content with its semantics._

# Typeof null

## Description
Create null, undefined variables and try typeof on them.

## Submission
- You do not have to submit anything for this problem

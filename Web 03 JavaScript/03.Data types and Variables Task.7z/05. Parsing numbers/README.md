# Parsing numbers

## Description
Try parsing the following strings to numbers using `parseInt`, `parseFloat`, `Number`, `+` and `| 0`. Fill the answers for yourself in the table below.

| str                    | parseInt(str) | parseFloat(str) | Number(str) | +str | `str | 0` |
|:---------------------- |:-------------:|:---------------:|:-----------:|:----:|:---------:|
| '1234'                 | ?             | ?               | ?           | ?    | ?         |
| '1238abc'              | ?             | ?               | ?           | ?    | ?         |
| '0.15'                 | ?             | ?               | ?           | ?    | ?         |
| '3.14ivan'             | ?             | ?               | ?           | ?    | ?         |
| 'Infinity'             | ?             | ?               | ?           | ?    | ?         |
| '99999999999999999999' | ?             | ?               | ?           | ?    | ?         |

## Submission
- You do not have to submit anything for this problem.
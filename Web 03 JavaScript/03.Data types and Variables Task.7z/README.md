Homework: Data types and Variables
==================================

### Problem List

1. [JavaScript literals](./01. JavaScript literals)
1. [Quoted text](./02. Quoted text)
1. [Typeof variables](./03. Typeof variables)
1. [Typeof null](./04. Typeof null)

# Typeof variables

## Description
Try typeof on all variables you created.

## Submission
- You do not have to submit anything for this problem

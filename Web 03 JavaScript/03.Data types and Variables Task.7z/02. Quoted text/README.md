# Quoted text

## Description
Create a string variable with quoted text in it.
For example: `'How you doin'?', Joey said'.`

## Submission
- You do not have to submit anything for this problem

# Say Hello

## Description
Write a method that asks the user for his name and prints `Hello, <name>!`.
Write a program to test this method.

## Input
- On the first line you will receive a name

## Output
- Print `Hello, <name>!`

## Constraints
- Time limit: **0.2s**
- Memory limit: **16MB**

## Sample tests

| Input | Output        |
|:------|:--------------|
| Peter | Hello, Peter! |


## Submission
- Submit your code [here](http://bgcoder.com/Contests/Compete/Index/361#0)

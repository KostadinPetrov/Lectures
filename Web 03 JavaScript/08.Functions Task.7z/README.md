Homework: Methods
=================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/361/JavaScript-Fundamentals-08-Functions)

### Problem List

1. [Say Hello](./01. Say Hello)
1. [Get largest number](./02. Get largest number)
1. [English digit](./03. English digit)
1. [Appearance count](./04. Appearance count)
1. [Larger than neighbours](./05. Larger than neighbours)
1. [First larger than neighbours](./06. First larger than neighbours)
1. [Reverse number](./07. Reverse number)
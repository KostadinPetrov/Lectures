Homework: Conditional statements
================================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/358/JavaScript-Fundamentals-05-Conditional-Statements)

### Problem List

1. [Exchange if greater](./01. Exchange if greater)
1. [Multiplication Sign](./02. Multiplication Sign)
1. [The biggest of Three](./03. The biggest of Three)
1. [Sort 3 numbers](./04. Sort 3 numbers)
1. [Digit as word](./05. Digit as word)
1. [Quadratic equation](./06. Quadratic equation)
1. [The biggest of five numbers](./07. The biggest of five numbers)
1. [Number as words](./08. Number as words)

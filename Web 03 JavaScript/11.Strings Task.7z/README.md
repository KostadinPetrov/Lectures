Homework: Strings
=================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/364/JavaScript-Fundamentals-11-Strings)

### Problem List

1. [Reverse string](./01. Reverse string)
1. [Correct brackets](./02. Correct brackets)
1. [Sub-string in text](./03. Sub-string in text)
1. [Parse tags](./04. Parse tags)
1. [nbsp](./05. nbsp)
1. [Extract text from HTML](./06. Extract text from HTML)
1. [Parse URL](./07. Parse URL)
1. [Replace tags](./08. Replace tags)
1. [Extract e-mails](./09. Extract e-mails)
1. [Find palindromes](./10. Find palindromes)
1. [String format](./11. String format)
1. [Generate list](./12. Generate list)

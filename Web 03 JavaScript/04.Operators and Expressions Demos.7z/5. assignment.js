'use strict';

let x = 6;
let y = 4;
console.log(y *= 2); // 8
let z = y = 3; // y=3 and z=3  
console.log(z); // 3
console.log(x |= 1); // 7
console.log(x += 3); // 10
console.log(x /= 2); // 5
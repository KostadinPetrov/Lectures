# Has property

## Description
Write a function that checks if a given object contains a given property.

```js
var obj  = …;
var hasProp = hasProperty(obj, 'length');
```

## Submission
- You do not have to submit anything for this problem

# Deep copy

## Description
Write a function that makes a deep copy of an object.
The function should work for both primitive and reference types.

## Submission
- You do not have to submit anything for this problem

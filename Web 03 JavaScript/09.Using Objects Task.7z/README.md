Homework: Using Objects
=======================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/362/JavaScript-Fundamentals-09-Using-Objects)

### Problem List

1. [Planar coordinates](./01. Planar coordinates)
1. [Remove elements](./02. Remove elements)
1. [Deep copy](./03. Deep copy)
1. [Has property](./04. Has property)
1. [Youngest person](./05. Youngest person)
1. [Group people](./06. Group people)

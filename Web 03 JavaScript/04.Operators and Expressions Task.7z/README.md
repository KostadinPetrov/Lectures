Homework: Operators and Expressions
===================================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/357/JavaScript-Fundamentals-04-Operators-and-Expressions)

### Problem List

1. [Odd or Even](./01. Odd or Even)
1. [Divide by 7 and 5](./02. Divisible by 7 and 5)
1. [Rectangles](./03. Rectangles)
1. [Third digit](./04. Third digit)
1. [3rd Bit](./05. Third bit)
1. [Point in a circle](./06. Point in Circle)
1. [Prime check](./07. Prime Check)
1. [Trapezoids](./08. Trapezoids)
1. [Point, Circle, Rectangle](./09. Point in Circle and outside Rectangle)

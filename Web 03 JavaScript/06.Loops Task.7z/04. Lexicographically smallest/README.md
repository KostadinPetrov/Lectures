# Lexicographically smallest

## Description
- Write a script that finds the lexicographically smallest and largest property in `document`, `window` and `navigator` objects. Write the script in an external `.js` file and refer it from a html page.
- Execute the same script under `NodeJS`. Why does it crash?

## Submission
- You do not have to submit anything for this task.

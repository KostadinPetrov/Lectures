# Permutations of set

## Description
Write a program that reads a number `N` and generates and prints all the permutations of the numbers [`1 … N`].

## Sample tests

| N |                                  result                                 |
|:-:|:-----------------------------------------------------------------------:|
| 3 | `{1, 2, 3}` <br> `{1, 3, 2}` <br> `{2, 1, 3}` <br> `{2, 3, 1}` <br> `{3, 1, 2}` <br> `{3, 2, 1}` |

## Submission
- You do not have to submit anything for this problem

# Find sum in array

## Description
Write a program that finds in given array of integers a sequence of given sum `S` (if present).

## Sample tests

|        array            |  S |  result |
|-------------------------|----|---------|
| 4, 3, 1, **4, 2, 5**, 8 | 11 | 4, 2, 5 |

## Submission
- You do not have to submit anything for this problem

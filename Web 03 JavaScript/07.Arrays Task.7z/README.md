Homework: Arrays
================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/360/JavaScript-Fundamentals-07-Arrays)

### Problem List

1. [Increase array members](./01. Increase array members)
1. [Lexicographically comparison](./02. Lexicographically comparison)
1. [Maximal sequence ](./03. Maximal sequence)
1. [Maximal increasing sequence](./04. Maximal increasing sequence)
1. [Selection sort](./05. Selection sort)
1. [Most frequent number](./06. Most frequent number)
1. [Binary search](./07. Binary search)

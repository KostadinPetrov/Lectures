# Average age of females

## Description
- Write a function that calculates the average age of all females, extracted from an array of persons
  - Use **Array#filter**
  - Use **only array methods** and no regular loops (`for`, `while`)

## Submission
- You do not have to submit anything for this problem

Homework: Methods on Arrays and Objects
=======================================

### Problem List

1. [Make person](./01. Make person)
1. [People of age](./02. People of age)
1. [Underage people ](./03. Underage people)
1. [Average age of females](./04. Average age of females)
1. [Youngest person](./05. Youngest person)
1. [Group people](./06. Group people)

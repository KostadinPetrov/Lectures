# Make person

## Description
- Write a function for creating persons.
  - Each person must have **firstname**, **lastname**, **age** and **gender** (`true` is female, `false` is male)
- Generate an array with ten person with different names, ages and genders

## Submission
- You do not have to submit anything for this problem

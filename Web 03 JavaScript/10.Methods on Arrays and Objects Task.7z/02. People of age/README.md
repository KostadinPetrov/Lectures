# People of age

## Description
- Write a function that checks if an array of person contains only people of age (with age 18 or greater)
  - Use **only array methods** and no regular loops (`for`, `while`)

## Submission
- You do not have to submit anything for this problem

# Underage people 

## Description
- Write a function that prints all underaged persons of an array of person
  - Use **Array#filter** and **Array#forEach**
  - Use **only array methods** and no regular loops (`for`, `while`)

## Submission
- You do not have to submit anything for this problem

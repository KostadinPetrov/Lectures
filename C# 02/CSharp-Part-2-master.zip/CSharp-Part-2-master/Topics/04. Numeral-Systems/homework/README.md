Homework: Numeral Systems
=========================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/318/CSharp-Advanced-04-Numeral-Systems)

### Problem List

1. [Decimal to binary](./01. Decimal to binary)
1. [Binary to decimal](./02. Binary to decimal)
1. [Decimal to hexadecimal](./03. Decimal to hexadecimal)
1. [Hexadecimal to decimal](./04. Hexadecimal to decimal)
1. [Hexadecimal to binary](./05. Hexadecimal to binary)
1. [Binary to hexadecimal](./06. Binary to hexadecimal)
1. [One system to any other](./07. One system to any other)
1. [Binary short](./08. Binary short)
1. [Binary floating-point](./09. Binary floating-point)

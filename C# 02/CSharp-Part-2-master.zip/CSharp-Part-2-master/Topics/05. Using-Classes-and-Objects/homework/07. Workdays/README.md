# Workdays

## Description
Write a method that calculates the number of workdays between today and a given date, passed as parameter.
Consider that workdays are all days from Monday to Friday except a fixed list of public holidays specified preliminary as array.

## Submission
- You do not have to submit anything for this problem

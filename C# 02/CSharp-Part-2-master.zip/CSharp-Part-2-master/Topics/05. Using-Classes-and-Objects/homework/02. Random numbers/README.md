# Random numbers

## Description
Write a program that generates and prints to the console `10` random values in the range [`100, 200`].

## Submission
- You do not have to submit anything for this problem

Homework: Using Classes and Objects
===================================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/319/CSharp-Advanced-05-Using-Classes-and-Objects)

### Problem List

1. [Leap year](./01. Leap year)
1. [Random numbers](./02. Random numbers)
1. [Day of week](./03. Day of week)
1. [Triangle surface by side and altitude](./04. Triangle surface by side and altitude)
1. [Triangle surface by three sides](./05. Triangle surface by three sides)
1. [Triangle surface by two sides and an angle](./06. Triangle surface by two sides and an angle)
1. [Workdays](./07. Workdays)
1. [Sum integers](./08. Sum integers)
1. [Arithmetical expressions](./09. Arithmetical expressions)

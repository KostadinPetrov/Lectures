# Download file

## Description
Write a program that downloads a file from Internet (e.g. [Ninja image](https://telerikacademy.com/Content/Images/news-img01.png)) and stores it the current directory.
Find in Google how to download files in C#.
Be sure to catch all exceptions and to free any used resources in the finally block.

## Submission
- You do not have to submit anything for this problem

Homework: Methods
=================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/317/CSharp-Advanced-03-Methods)

### Problem List

1. [Say Hello](./01. Say Hello)
1. [Get largest number](./02. Get largest number)
1. [English digit](./03. English digit)
1. [Appearance count](./04. Appearance count)
1. [Larger than neighbours](./05. Larger than neighbours)
1. [First larger than neighbours](./06. First larger than neighbours)
1. [Reverse number](./07. Reverse number)
1. [Number as array](./08. Number as array)
1. [Sorting array](./09. Sorting array)
1. [N Factorial](./10. N Factorial)
1. [Adding polynomials](./11. Adding polynomials)
1. [Subtracting polynomials](./12. Subtracting polynomials)
1. [Solve tasks](./13. Solve tasks)
1. [Integer calculations](./14. Integer calculations)
1. [Number calculations](./15. Number calculations)

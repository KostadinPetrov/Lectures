# Reverse number

## Description
Write a method that reverses the digits of a given decimal number.

## Input
- On the first line you will receive a number

## Output
- Print the given number with reversed digits

## Constraints
- Time limit: **0.1s**
- Memory limit: **16MB**

## Sample tests

| Input  | Output |
|:-------|:-------|
| 256    | 652    |
| 123.45 | 54.321 |

## Submission
- Submit your code [here](http://bgcoder.com/Contests/Compete/Index/317#6)

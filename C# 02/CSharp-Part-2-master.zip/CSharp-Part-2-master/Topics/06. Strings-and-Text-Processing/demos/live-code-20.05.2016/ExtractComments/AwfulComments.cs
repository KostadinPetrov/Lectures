﻿namespace ExtractComments
{
    // my usings are here
    using System;

    // penka e yaka macka
    class Gosho
    {
        // otivam na kafe s ivan // /* dsfdsf
        static void Sorry()
        {
            var code = ""; /* koito go e pisal tozi kod,
             sdflkjdsjfldsfjlkdsfjdslkfjdlkf /* /// ///dskfskjlsd
             ne e dobre */
        }
        // javascript
    }
}
// za cvqt

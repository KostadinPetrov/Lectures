# Reverse sentence

## Description
Write a program that reverses the words in a given sentence.

## Sample tests

| Input                                  | Output                                 |
|:---------------------------------------|:---------------------------------------|
| C# is not C++, not PHP and not Delphi! | Delphi not and PHP, not C++ not is C#! |

## Submission
- You do not have to submit anything for this problem

# Date difference

## Description
*	Write a program that reads two dates in the format: `day.month.year` and calculates the number of days between them.

_Example:_

	Enter the first date: 27.02.2006
	Enter the second date: 3.03.2006
	Distance: 4 days

## Submission
- You do not have to submit anything for this problem

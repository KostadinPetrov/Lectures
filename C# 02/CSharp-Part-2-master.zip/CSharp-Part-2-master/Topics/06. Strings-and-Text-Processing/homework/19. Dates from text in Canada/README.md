# Dates from text in Canada

## Description
Write a program that extracts from a given text all dates that match the format `DD.MM.YYYY`.
Display them in the standard date format for Canada.

## Submission
- You do not have to submit anything for this problem

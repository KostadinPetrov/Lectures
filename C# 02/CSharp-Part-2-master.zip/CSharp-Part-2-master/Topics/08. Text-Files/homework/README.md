Homework: Text files
====================

### Problem List

1. [Odd lines](./01. Odd lines)
1. [Concatenate text files](./02. Concatenate text files)
1. [Line numbers](./03. Line numbers)
1. [Compare text files](./04. Compare text files)
1. [Maximal area sum](./05. Maximal area sum)
1. [Save sorted names](./06. Save sorted names)
1. [Replace sub-string](./07. Replace sub-string)
1. [Replace whole word](./08. Replace whole word)
1. [Delete odd lines](./09. Delete odd lines)
1. [Extract text from XML](./10. Extract text from XML)
1. [Prefix "test"](./11. Prefix test)
1. [Remove words](./12. Remove words)
1. [Count words](./13. Count words)

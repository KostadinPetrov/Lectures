# Replace whole word

## Description
Modify the solution of the previous problem to replace only **whole words** (not strings).

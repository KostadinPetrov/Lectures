# Extract text from XML

## Description
Write a program that extracts from given XML file all the text without the tags.

_Example:_

`<?xml version="1.0"><student><name>Pesho</name><age>21</age><interests count="3"><interest>Games</interest><interest>C#</interest><interest>Java</interest></interests></student>`


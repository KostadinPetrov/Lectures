# Prefix "test"

## Description
Write a program that deletes from a text file all words that start with the prefix `test`.
Words contain only the symbols `0…9`, `a…z`, `A…Z`, `_`.

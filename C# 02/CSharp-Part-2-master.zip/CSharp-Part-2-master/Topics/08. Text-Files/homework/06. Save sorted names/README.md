# Save sorted names

## Description
Write a program that reads a text file containing a list of strings, sorts them and saves them to another text file.

_Example:_

|  input.txt | output.txt |
|:----------:|:----------:|
| Ivan <br> Peter <br> Maria <br> George | George <br> Ivan <br> Maria <br> Peter |


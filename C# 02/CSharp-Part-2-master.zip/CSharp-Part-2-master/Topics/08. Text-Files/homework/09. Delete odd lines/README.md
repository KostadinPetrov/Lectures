# Delete odd lines

## Description
Write a program that deletes from given text file all odd lines.
The result should be in the same file.

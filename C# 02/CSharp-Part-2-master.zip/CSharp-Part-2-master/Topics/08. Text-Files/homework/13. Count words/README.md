# Count words

## Description
Write a program that reads a list of words from the file `words.txt` and finds how many times each of the words is contained in another file `test.txt`.
The result should be written in the file `result.txt` and the words should be sorted by the number of their occurrences in descending order.
Handle all possible exceptions in your methods.

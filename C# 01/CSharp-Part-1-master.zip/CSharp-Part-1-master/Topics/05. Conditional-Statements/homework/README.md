Homework: Conditional Statements
================================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/309/CSharp-Fundamentals-05-Conditional-Statements)

### Problem List

1. [Exchange numbers](./01. Exchange If Greater)
1. [Bonus Score](./02. Bonus Score)
1. [Play card](./03. Check for a Play Card)
1. [Multiplication sign](./04. Multiplication Sign)
1. [Biggest of 3](./05. Biggest of 3)
1. [Biggest of 5](./06. Biggest of 5)
1. [Sort 3 Numbers](./07. Sort 3 Numbers)
1. [Digit as Word](./08. Digit as Word)
1. [Int, Double, String](./09. Int, Double and String)

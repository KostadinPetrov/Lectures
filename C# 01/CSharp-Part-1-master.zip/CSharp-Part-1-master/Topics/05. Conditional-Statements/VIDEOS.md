#   Videos for the Conditional Statements presentation

<!-- video -->
#### Evlogi Hristov
13 April 2016<br/>
[![13 April 2016 - Evlogi](https://img.youtube.com/vi/Aoy6rGiu9WA/default.jpg)](https://www.youtube.com/watch?v=Aoy6rGiu9WA)

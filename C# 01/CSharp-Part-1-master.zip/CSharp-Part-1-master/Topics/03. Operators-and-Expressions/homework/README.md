Homework: Operators and Expressions
===================================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/310/CSharp-Fundamentals-03-Operators-and-Expressions)

### Problem List

1. [Odd or Even](./01. Odd or Even)
1. [Moon Gravity](./02. Moon Gravity)
1. [Divide by 7 and 5](./03. Divide by 7 and 5)
1. [Rectangles](./04. Rectangles)
1. [Third digit](./05. Third digit)
1. [Four digits](./06. Four digits)
1. [Point in a circle](./07. Point in a circle)
1. [Prime check](./08. Prime Check)
1. [Trapezoids](./09. Trapezoids)
1. [Point, Circle, Rectangle](./10. Point, Circle, Rectangle)
1. [3rd Bit](./11. 3rd Bit)
1. [N-th Bit](./12. N-th bit)
1. [Modify Bit](./13. Modify Bit)
1. [BitExchange](./14. BitExchange)
1. [BitSwap](./15. BitSwap)

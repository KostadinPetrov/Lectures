#   Videos for the Operators and Expressions presentation

<!-- video -->
#### Evlogi Hristov
6 April 2016<br/>
[![6 April 2016 - Evlogi](https://img.youtube.com/vi/dCOBmzfEXbk/default.jpg)](https://www.youtube.com/watch?v=dCOBmzfEXbk)

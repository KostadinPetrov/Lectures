Homework: Console IO
====================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/311/CSharp-Fundamentals-04-Console-Input-and-Output)

### Problem List

1. [Sum of 3 numbers](./01. Sum of 3 numbers)
1. [Company info](./02. Company Info)
1. [Circle](./03. Circle)
1. [Formatting Numbers](./04. Formatting Numbers)
1. [Number Comparer](./05. Numbers Comparer)
1. [Quadratic Equation](./06. Quadratic Equation)
1. [Sum of 5 numbers](./07. Sum of 5 Numbers)
1. [Numbers from 1 to N](./08. Numbers from 1 to n)
1. [Sum of N Numbers](./09. Sum of n Numbers)
1. [Fibonacci Numbers](./10. Fibonacci Numbers)
1. [Interval](./11. Interval)
1. [Falling Rocks](./12. Falling rocks)

# Combinations of set

## Description
Write a program that reads two numbers `N` and `K` and generates all the combinations of `K` distinct elements from the set [`1..N`].

## Sample tests

| N | K |                                          result                                           |
|:-:|:-:|:-----------------------------------------------------------------------------------------:|
| 5 | 2 | `{1, 2}` <br> `{1, 3}` <br> `{1, 4}` <br> `{1, 5}` <br> `{2, 3}` <br> `{2, 4}` <br> `{2, 5}` <br> `{3, 4}` <br> `{3, 5}` <br> `{4, 5}` |

## Submission
- You do not have to submit anything for this problem

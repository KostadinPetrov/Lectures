# Subset K with sum S

## Description
Write a program that reads three integer numbers `N`, `K` and `S` and an array of `N` elements from the console.
- Find in the array a subset of `K` elements that have sum `S` or indicate about its absence.

## Submission
- You do not have to submit anything for this problem

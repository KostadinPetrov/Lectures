Homework: Arrays
================

### [Submit homework in bgcoder](http://bgcoder.com/Contests/315/CSharp-Advanced-01-Arrays)

### Problem List

1. [Allocate array](./01. Allocate array)
1. [Compare arrays](./02. Compare arrays)
1. [Compare char arrays](./03. Compare char arrays)
1. [Maximal sequence](./04. Maximal sequence)
1. [Maximal increasing sequence](./05. Maximal increasing sequence)
1. [Maximal K sum](./06. Maximal K sum)
1. [Selection sort](./07. Selection sort)
1. [Maximal sum](./08. Maximal sum)
1. [Frequent number](./09. Frequent number)
1. [Find sum in array](./10. Find sum in array)
1. [Binary search](./11. Binary search)
1. [Index of letters](./12. Index of letters)
1. [Merge sort](./13. Merge sort)
1. [Quick sort](./14. Quick sort)
1. [Prime numbers](./15. Prime numbers)
1. [Subset with sum S](./16. Subset with sum S)
1. [Subset K with sum S](./17. Subset K with sum S)
1. [Remove elements from array](./18. Remove elements from array)
1. [Permutations of set](./19. Permutations of set)
1. [Variations of set](./20. Variations of set)
1. [Combinations of set](./21. Combinations of set)
1. [Command line arguments](./22. Command line arguments)

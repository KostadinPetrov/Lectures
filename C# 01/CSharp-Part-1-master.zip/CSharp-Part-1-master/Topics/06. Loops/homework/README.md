Homework: Loops
===============

### [Submit homework in bgcoder](http://bgcoder.com/Contests/312/CSharp-Fundamentals-06-Loops)

### Problem List

1. [Numbers from 1 to N](./01. Numbers from 1 to N)
1. [Not Divisible Numbers](./02. Not Divisible Numbers)
1. [MMSA(Min, Max, Sum, Average) of N Numbers](./03. MMSA of N Numbers)
1. [Print a Deck](./04. Print a Deck)
1. [Calculate!](./05. Calculate!)
1. [Calculate Again](./06. Calculate Again!)
1. [Calculate 3!](./07. Calculate 3!)
1. [Catalan Numbers](./08. Catalan Numbers)
1. [Matrix of Numbers](./09. Matrix of Numbers)
1. [Odd and Even Product](./10. Odd and Even Product)
1. [Binary to Decimal](./11. Binary to Decimal)
1. [Decimal to Binary](./12. Decimal to Binary)
1. [Decimal to Hex](./13. Decimal to Hex)
1. [Hex to Decimal](./14. Hex to Decimal)
1. [GCD](./15. GCD)
1. [Trailing 0 in N!](./16. Trailing 0 in N!)
1. [Spiral Matrix](./17. Spiral Matrix)

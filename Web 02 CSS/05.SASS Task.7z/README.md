SASS
====

### Problem 1. Forum Post
*	Implement the following using SASS
	*	Use the [HTML](https://github.com/TelerikAcademy/CSS/blob/master/Topics/04.%20SASS/homework/homework.html) code
	*	Make the SASS easy to change (backgrounds, fonts)
	*	Use mixins for clears, gradients

![picture1](https://cloud.githubusercontent.com/assets/3619393/7184114/1f79cb80-e464-11e4-9a3d-5c916c0390ce.png)

### Problem 2. Web Gallery
*	Create a web gallery
	*	Use only HTML, SASS, and CSS
	*	List images
	*	When an image is selected, show it zoomed

![picture2](https://cloud.githubusercontent.com/assets/3619393/7185067/4abe223c-e469-11e4-80a7-e6750fa89e63.png)

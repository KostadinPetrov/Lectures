﻿using System;
using System.Linq;

class LINQQueries
{
    static void Main()
    {
    }
}

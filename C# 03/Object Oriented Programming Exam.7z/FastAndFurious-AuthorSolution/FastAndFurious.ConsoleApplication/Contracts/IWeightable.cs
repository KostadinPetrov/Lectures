﻿namespace FastAndFurious.ConsoleApplication.Contracts
{
    public interface IWeightable
    {
        int Weight { get; }
    }
}

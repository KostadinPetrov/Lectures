﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum TurbochargerType
    {
        NotSet = 0,
        TwinTurbo,
        TwinScroll,
        SequentialTurbo
    }
}

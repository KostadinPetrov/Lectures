﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum CylinderType
    {
        NotSet = 0,
        V6,
        V8,
        V12,
        V16
    }
}

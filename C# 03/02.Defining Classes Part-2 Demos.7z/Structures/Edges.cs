﻿public enum Edges
{ 
	Straight, 
	Rounded 
}

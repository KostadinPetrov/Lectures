﻿using System;

namespace SofiaUniversity
{
    public class AdministrationSystem
    {
        static void Main()
        {
            // ...
        }
    }
}

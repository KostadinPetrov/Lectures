﻿using System;

namespace SofiaUniversity.Data
{
    public struct Faculty
    {
        public string Name { get; set; }
    }
}

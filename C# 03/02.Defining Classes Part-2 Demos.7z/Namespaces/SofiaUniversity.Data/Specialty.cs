﻿using System;

namespace SofiaUniversity.Data
{
    public enum Specialty
    {
        ComputerScience,
        SoftwareEngineering,
        InformationSystems
    }
}

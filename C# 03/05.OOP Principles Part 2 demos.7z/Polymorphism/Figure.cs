﻿public abstract class Figure
{
    public abstract double CalcSurface();
}

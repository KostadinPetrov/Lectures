﻿internal class SpecialFigure : Figure
{
}

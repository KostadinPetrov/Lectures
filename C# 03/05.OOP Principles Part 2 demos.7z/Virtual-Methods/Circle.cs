﻿using System;

internal class Circle : Figure
{
    public override void Draw()
    {
        Console.WriteLine("I am a circle:");
        Console.WriteLine(" --- ");
        Console.WriteLine("|   |");
        Console.WriteLine(" --- ");
    }
}

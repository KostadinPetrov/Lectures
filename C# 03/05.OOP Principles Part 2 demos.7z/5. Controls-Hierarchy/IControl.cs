﻿public interface IControl
{
    double Size
    {
        get;
    }
}
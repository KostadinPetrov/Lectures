﻿public class Button : Control
{
    public override double Size
    {
        get
        {
            return 10;
        }
    }
}
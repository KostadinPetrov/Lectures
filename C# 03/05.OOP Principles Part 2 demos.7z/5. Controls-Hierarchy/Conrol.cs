﻿public abstract class Control : IControl
{
    public abstract double Size
    {
        get;
    }
}
﻿namespace Societies.Core.Contracts
{
    using System.Collections.Generic;

    public interface ICustomCollection<T> : IList<T>
    {
    }
}

﻿namespace Societies.Core.Infrastructure.Enumerations.Common
{
    public enum FoodType
    {
        FruitSalad = 10,
        VegetablesSalad = 12,
        Pizza = 20,
        Spaghetti = 30,
        Chocolate = 999
    }
}

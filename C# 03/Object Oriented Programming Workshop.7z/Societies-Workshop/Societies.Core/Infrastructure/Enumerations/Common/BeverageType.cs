﻿namespace Societies.Core.Infrastructure.Enumerations.Common
{
    public enum BeverageType
    {
        GreenTea = 5,
        BlackTea = 4,
        WhiteTea = 12,
        Coffee = 13,
        Beer = 15,
        CoconutMilk = 9,
        MineralWater = 8,
        WellWater = 11
    }
}

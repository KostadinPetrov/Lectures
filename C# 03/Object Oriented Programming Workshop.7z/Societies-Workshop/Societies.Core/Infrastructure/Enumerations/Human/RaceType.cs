﻿namespace Societies.Core.Infrastructure.Enumerations.Human
{
    public enum RaceType
    {
        NotSet =0,
        European,
        African,
        Asian,
        Indian
    }
}

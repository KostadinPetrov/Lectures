﻿namespace Societies.Core.Infrastructure.Enumerations.Human
{
    public enum ReligionType
    {
        NotSet = 0,
        Christianity,
        Hinduism,
        Islamism,
        Judaism,
        Atheism,
        Agnosticism
    }
}

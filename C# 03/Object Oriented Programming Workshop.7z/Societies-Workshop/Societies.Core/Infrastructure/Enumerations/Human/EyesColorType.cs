﻿namespace Societies.Core.Infrastructure.Enumerations.Human
{
    public enum EyesColorType
    {
        NotSet = 0,
        Brown,
        Black,
        Gray,
        Blue,
        Green,
        Mixed
    }
}

﻿namespace Societies.Core.Infrastructure.Enumerations.Human
{
    public enum FaceShapeType
    {
        NotSet = 0,
        Oblong,
        Square,
        Heart,
        Diamond
    }
}

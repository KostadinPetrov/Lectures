﻿namespace Societies.Core.Infrastructure.Enumerations.Human
{
    public enum HairColorType
    {
        NotSet = 0,
        Black,
        Brown,
        White,
        Gray,
        Pink,
        Green,
        Blue
    }
}

﻿namespace Societies.Core.Infrastructure.Enumerations.Human
{
    public enum GenderType
    {
        NotSet = 0,
        Male,
        Female
    }
}

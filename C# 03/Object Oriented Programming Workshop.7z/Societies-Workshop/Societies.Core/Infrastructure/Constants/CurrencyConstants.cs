﻿namespace Societies.Core.Infrastructure.Constants
{
    public class CurrencyConstants
    {
        public const decimal SoftwareEngineerBakshishPercentage = 0.15m;
        public const decimal SoftwareEngineerSalaryPerHour = 80m;
    }
}
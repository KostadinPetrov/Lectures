﻿using System;

class FiguresExample
{
    static void Main()
    {

    }
}

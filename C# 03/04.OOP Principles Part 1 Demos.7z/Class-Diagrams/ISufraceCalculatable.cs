﻿using System;

interface ISufraceCalculatable
{
    float CalculateSurface();
}

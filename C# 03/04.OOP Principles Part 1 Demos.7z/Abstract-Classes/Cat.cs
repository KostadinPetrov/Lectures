﻿public abstract class Cat : Animal
{
	public string Breed { get; set; }
	public abstract void SayMyaau();
}
